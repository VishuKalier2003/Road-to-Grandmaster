## Commutative Operations

### Trigger
When a commutative operationn like (a+b), (a*b), etc. are applied on a set of elements to check if the output is possible

### Mistakes
- Thinking about recursion when the approach can be solved by mathematics

### Idea
- Say for output y, any element that jumps out of the range, like for example greater than y can be neglected
- Rest elements can apply the operations commutatively and then we can check whether the result exist

### One Liner
- For commutative operations (a*b) to check feasibility, the order doesn't matter so no need to use recursion to pick and drop

### Problem

Related problems are given below-

| S. No. | Problem Name | Problem | Rating |
|-|-|-|-|
| 1. | 2048 Game | [1221A](https://codeforces.com/problemset/problem/1221/A) | 1000 |